<script setup>
import sortable from './components/sortable.vue'
import toggle_listVue from './components/toggle_list.vue'
import PaginationVue from './components/pagination.vue';
//import TheWelcome from './components/TheWelcome.vue'
</script>

<template>
  <header>
   <!--<img alt="Vue logo" class="logo" src="./assets/logo.svg" width="125" height="125" />-->

    <div class="wrapper">
      <sortable/>
    </div>
  </header>

  <main>
    <toggle_listVue/>
    
  </main>
  <div class="pagination">
    <PaginationVue/>
  </div>
  
  



</template>

<style scoped>
.pagination{
       display: flex;
       padding-bottom: 20%;
}


main {
  padding:23px;
  background-color: #fff;
  /* background: #1E1E1E; */
  width: 100%;
  
  border: 1px solid #E0E2E4;
  border-radius: 8px;

  
}




</style>
