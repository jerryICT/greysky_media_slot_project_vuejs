<script setup>
defineProps({

})
</script>

<template>
    <div class="titled-Product">
     <h1>Products</h1>
    </div>
</template>


<style scoped>


.titled-product{
    height: 32px;
    width: 100px;
    left: 15px;
    top: 0px;
    border-radius: 0px;
    

}

h1{
font-family: Bitter;
font-size: 24px;
font-weight: 500;
line-height: 32px;
letter-spacing: 0em;
text-align: left;
}



</style>
