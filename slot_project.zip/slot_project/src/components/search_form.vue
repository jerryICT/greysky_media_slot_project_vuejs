<script setup>

</script>

<template>

  
</template>


<style scoped>

.btn1{
    /* Buttons */


/* Auto layout */

/* Primary: Blue */
line-height: 35px;
background: #375673;
border-radius: 4px;
border: 0px;
color: #fff;

/* Inside auto layout */

flex: none;
order: 1;
flex-grow: 0;
}
.btn2{
    /* Buttons */


/* Auto layout */

/* Primary: Blue */
line-height: 35px;
background: #377364;
border-radius: 4px;
border: 0px;
color: #fff;

/* Inside auto layout */

flex: none;
order: 1;
flex-grow: 0;
}


input[type="text"]{
width: 324px;
/* Text | Regular */

line-height: 25px;
padding: 5px;
margin: 2px;
/* identical to box height, or 157% */


/* Grey: Default Text */

color: #939597;


/* Inside auto layout */

flex: none;
order: 0;
flex-grow: 1;
}

.searchinput{
    max-width: 76%;
}

h1{
font-family: Bitter;
font-size: 24px;
font-weight: 500;
line-height: 32px;
letter-spacing: 0em;
text-align: left;
}



</style>
