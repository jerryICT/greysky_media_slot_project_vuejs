<script setup>

</script>

<template>
   <div class="pagediv">
    <div class="numdiv">
           page <p class="pnum">1</p> of <p class="pnum">2</p>
    </div>
    </div>
    <div class="sortdiv">
           Sort by<p class="pnum">Sort Order 10</p>  
           <img src="..//assets/arrowdown.png" alt="" class="arrowdown">   
    </div> 
   
   
         
</template>


<style scoped>
.arrowdown{
     right: 15%;
}

.sortdiv{
    display: flex;
    position: absolute;
    left: 50%;
    width: 50%;
    top: 12%;
    
    
    
    
}
.pagediv{
/* display: flex;*/
    width: 100%; 
    padding: 8px;
    display: flex;
    font-family: 'Inter';
    font-style: normal;
    position: absolute;

}
.numdiv{
    display: flex;
    font-family: 'Inter';
    font-style: normal;
    position: absolute;
    
}
.pnum{ 
      
      left: 5%;
      Font-weight: 545;
      font-family: 'Inter';
      
      
      
}
</style>
