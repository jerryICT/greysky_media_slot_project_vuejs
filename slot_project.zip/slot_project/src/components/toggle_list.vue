<template>
    <div class="formdiv">
        <form action="">
            <input type="text" placeholder="Find a Product" v-model="search"><button class="btn1">Search</button>
        </form>

        <form action="">
            <input type="text" class="searchinput" placeholder="Product Name"><button class="btn2">Add Product</button>
        </form>
    </div>  
    <div class="cards">
        <div class="card" v-for="card in filteredList" key=card.name>
            <div>
                <img :src=card.image class="img2" v-if="card.image">
                <img src='../assets/unsplash_cmQqRwJ-MpQ.png' class="img2" v-else>
                <img src="../assets/icong.png" alt="" class="alertg2" v-if="card.status == 'green'">
                <img src="../assets/red.png" alt="" class="alertg3"  v-if="card.status == 'red'">
                <img src="../assets/yellow.png" alt="" class="alertg3"  v-if="card.status == 'yellow'">
                <p class="p2">{{card.name}}</p>
                <p class="date" v-if="card.date">{{convertDate(card.date)}}</p>
                <img src="..//assets/arrowdown.png" alt="" class="vector2">
            </div>     
        </div>

  </div>
</template>

<script>
    export default {
        name:'toggleList',
        data () {
            return {
                testData: [
                {
                    name: 'Americano',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Espresso',
                    image: 'https://picsum.photos/48',
                    status: 'yellow',
                    date: null,
                },
                {
                    name: 'Mocha',
                    image: '',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'White Mocha',
                    image: '',
                    status: 'yellow',
                    date: 704305433,
                },
                {
                    name: 'Latte',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: 1666715033,
                },
                {
                    name: 'Cappucino',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Walking with Giants',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Turbinator 2',
                    image: 'https://picsum.photos/48',
                    status: 'red',
                    date: null,
                },
                {
                    name: 'Super Cali',
                    image: '',
                    status: 'red',
                    date: 704305433,
                },
                {
                    name: 'Baseball Hat',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Americano',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Espresso',
                    image: 'https://picsum.photos/48',
                    status: 'yellow',
                    date: null,
                },
                {
                    name: 'Mocha',
                    image: '',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'White Mocha',
                    image: '',
                    status: 'yellow',
                    date: 704305433,
                },
                {
                    name: 'Latte',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: 1666715033,
                },
                {
                    name: 'Cappucino',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Walking with Giants',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },
                {
                    name: 'Turbinator 2',
                    image: 'https://picsum.photos/48',
                    status: 'red',
                    date: null,
                },
                {
                    name: 'Super Cali ',
                    image: '',
                    status: 'red',
                    date: 704305433,
                },
                {
                    name: 'Baseball Hat',
                    image: 'https://picsum.photos/48',
                    status: 'green',
                    date: null,
                },

                ],
                search:''
            }
        },
        computed: {
            filteredList() {
                return this.testData.filter(card => {
                    return card.name.toLowerCase().includes(this.search.toLowerCase())
                })
            }
        },
        methods: {
            convertDate (timestamp) {
                const unixTimeStamp = timestamp
                const miliseconds = unixTimeStamp * 1000
                const dateObject = new Date(miliseconds)
                const yearString = dateObject.getFullYear()
                return dateObject.getDate() + "/" + dateObject.getMonth() + 1 + "/" + yearString.toString().substr(-2)
            }
        }
    }
</script>


<style scoped>

.formdiv{
    margin-bottom: 5px;
}
.cards {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-gap: 1rem;
}
.cards > div {
    color: #252526;
    background-color: #fff;
    border-bottom: 1px solid #E0E2E4;
    height: auto;
} 
/* Screen  from 600px? below 2 column */
@media (min-width: 600px) {
  .cards { grid-template-columns: repeat(1, 1fr); }
}

/* Screen larger than 900px? 3 columns */
@media (min-width: 768px) {
  .cards { grid-template-columns: repeat(2, 1fr); }
}


.vector2{
position: absolute;
right: 5%;
top: 27.98%;
bottom: 37.14%;
    }

.date{
position: absolute;
right: 20.83%;
top: 9.98%;
left: 66%;
font-family: 'Inter';
font-style: normal;
font-weight: 400;
font-size: 9px;
line-height: 22px;
color: #252526;
}

.p2{
position: absolute;
right: 20.83%;
top: 10.98%;
left: 43px;
font-family: 'Inter';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 22px;
color: #252526;
}

.alertg2{
width: 16px;
height: 16px;
}

.alertg3{
width: 10px;
height: 10px;
margin:2px;
}


.img2{
width: 24px;
height: 24px;
border-radius: 2px;
flex: none;
order: 0;
flex-grow: 0;
}

.child2 {
     width: 50%;
     color: #252526;
     padding: 5px;
     /* background-color: yellow; */
     margin: 2px;
            }


            .btn1{
    /* Buttons */


/* Auto layout */

/* Primary: Blue */
line-height: 35px;
background: #375673;
border-radius: 4px;
border: 0px;
color: #fff;

/* Inside auto layout */

flex: none;
order: 1;
flex-grow: 0;
}
.btn2{
    /* Buttons */


/* Auto layout */

/* Primary: Blue */
line-height: 35px;
background: #377364;
border-radius: 4px;
border: 0px;
color: #fff;

/* Inside auto layout */

flex: none;
order: 1;
flex-grow: 0;
}


input[type="text"]{
width: 324px;
/* Text | Regular */

line-height: 25px;
padding: 5px;
margin: 2px;
/* identical to box height, or 157% */


/* Grey: Default Text */

color: #939597;


/* Inside auto layout */

flex: none;
order: 0;
flex-grow: 1;
}

.searchinput{
    max-width: 76%;
}

h1{
font-family: Bitter;
font-size: 24px;
font-weight: 500;
line-height: 32px;
letter-spacing: 0em;
text-align: left;
}
</style>
